//import java.util.Scanner;
//import static java.lang.Math.*;
//public class Main {
//public static void main(String[] args) {
//        final double E = 0.001;// величина приближения
//        double A, S;
//        int n;// число итераций
//        Scanner in = new Scanner(System.in);
//        System.out.print("x=");
//        double x = in.nextDouble();
//        S = 0;
//        n = 0;
//        A = 2 * x/3;
//        do {
//            S = S + A;
//            n = n + 1;
//           System.out.printf("A%d=%.4f, сумма=%.4f\n", n, A, S);
//            A = A * (pow(2, n + 1) / (6 * n));
//        }
//        while (abs(A) >= E);
//        System.out.printf("Сумма членов ряда S=%.4f, число итераций N=%d", S, n);
//    }
//}
import java.util.Scanner;
import static java.lang.Math.*;

public class Main {
    public static void main(String[] args) {
        final double E = 0.001; // величина приближения
        double A, S;
        int n; // число итераций
        Scanner in = new Scanner(System.in);

        System.out.print("x=");
        double x = in.nextDouble();

        S = 0;
        n = 0;
        A = x / 3; // начальное значение A

        do {
            S = S + A; // суммируем
            n = n + 1; // увеличиваем счетчик итераций

            // Выводим текущие A и сумму
            System.out.printf("A%d=%.4f, сумма=%.4f\n", n, A, S);

            // Обновляем A с использованием формулы для след. члена ряда
            A = (2 * pow(x, n + 1)) / (3 * factorial(n)); // исправлено на правильное обновление A

        } while (abs(A) >= E); // условие продолжения цикла

        System.out.printf("Сумма членов ряда S=%.4f, число итераций N=%d", S, n);
    }

    // Метод для вычисления факториала
    public static double factorial(int num) {
        double result = 1;
        for (int i = 1; i <= num; i++) {
            result *= i;
        }
        return result;
    }
}