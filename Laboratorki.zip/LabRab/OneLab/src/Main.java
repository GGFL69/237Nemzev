import java.util.Scanner;

import static java.lang.Math.*;

public class Main {
    public static void main(String[] args) {
        //Лаб. работа 1
        //Студент гр.237, фамилия - Немцев
        //Описание констант
        final double a = 3.0;
        final double b = 5.0;
        Scanner in = new Scanner(System.in);
        System.out.print("Введите x = ");
        double x = in.nextDouble();
        //Вычисление значений y и f
        double y = pow(a*x,5)*atan(a+x)-sqrt(abs(x-a))+log(pow(x+1,2));
        double f = x*(sqrt(pow(a*x,2))+b*x)+exp(-x);
        //Вывод результатов
        System.out.printf("При X=%.3f, Y=%.3f, F=%.3f\n",x,y,f);
    }
}