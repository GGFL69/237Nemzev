import java.util.Scanner;

import static java.lang.Math.pow;

public class Fuction {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.print("c = ");
        int c = in.nextInt();
        System.out.print("x = ");
        int x = in.nextInt();
        System.out.print("k = ");
        int k = in.nextInt();
        double F = (pow(c-x,k))/pow(c,k)*(Fct(c)-Fct(k));
        System.out.print("F = " + F);
    }
    static double Fct(int nn){
        double x = 1;
        for (int i = 1; i <= nn; i++) {
            x = x * i;
        }
        return x;
    }
}