import java.util.Scanner;

import static java.lang.Math.pow;

public class Procedure {
    static class Factorial {
        int v;
    }
    static void f(int x, Factorial p) {
        p.v=1;
        for (int i = 1; i <= x; i++) {
            p.v *= i;
        }
    }
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.print("c = ");
        int c = in.nextInt();
        System.out.print("x = ");
        int x = in.nextInt();
        System.out.print("k = ");
        int k = in.nextInt();
        Factorial r = new Factorial();
        f(c, r);
        int p1 = r.v;
        f(k, r);
        int p2 = r.v;
        double F = pow(c-x,k)/pow(c,k)*(p1-p2);
        System.out.print("F = "+F);
    }
}