import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        double x;
        System.out.print("Введите a = ");
        int a = in.nextInt();
        System.out.print("Введите b = ");
        int b = in.nextInt();
        if(a>b)
            x=b*a+1;
        else if(a==b)
            x=3425;
        else if(b!=0)
            x=(2*a-5)/(b*1.0);
        else{
            System.out.println("Знаменатель в выражении (3) равен 0");
            return;
        }
        System.out.printf("При a=%d и b=%d, x=%.3f",a,b,x);
    }
}