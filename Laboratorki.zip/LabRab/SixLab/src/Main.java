import java.util.Scanner;

import static java.lang.Math.*;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.print("n=");
        int n = in.nextInt();
        double P = 1;
        for (int k = 1; k <= n; k++) {
            P = P*1/(k+(3*k-1));
        }
        System.out.printf("При n=%d P=%.6f", n, P);
        }
    }
