import java.util.Scanner;

import static java.lang.Math.*;

public class Main {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.print("Введите x = ");
        double x = in.nextDouble();
        int start = 1;
        int end = 5;
        System.out.println("S = " + f(x, start, end));
    }
    private static double f(double x, int start, int end){
        if (start>end) return 0;
        return 1/pow(x, start) + f(x, start + 1, end);
    }
}