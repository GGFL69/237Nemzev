import java.util.Scanner;

import static java.lang.Math.*;

public class Main {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.print("x = ");
        double x = in.nextDouble();
        double S = 0;
        int k = 1;
        while (k<=5){
            S=S+1/ pow(x,k);
            k++;
        }
        System.out.printf("При x=%.2f, S=%.3f",x,S);
    }
}