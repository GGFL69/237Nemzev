import java.util.Scanner;

import static java.lang.Math.*;

public class Main2 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.print("x = ");
        double x = in.nextDouble();
        double S = 0;
        int k = 5;
        while (k>=1){
            S=S+1/ pow(x,k);
            k--;
        }
        System.out.printf("При x=%.2f, S=%.3f",x,S);
    }
}