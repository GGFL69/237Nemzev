import java.util.Scanner;

import static java.lang.Math.*;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.print("Введите А=");
        double A = in.nextDouble();
        System.out.print("Введите B=");
        double B = in.nextDouble();
        System.out.print("Введите H=");
        double H = in.nextDouble();
        double x = floor(A * 100.0) / 100.0;
        double y;
        do {
            if (pow(x,2)-4<=0)
                System.out.printf("при х=%.1f под знаком логарифма недопустимое значение\n", x);
            else {
                y = (pow(x,2)+sin(x)/cos(x))/log(pow(x,2)-4);
                System.out.printf("при х=%.1f y=%.3f\n", x, y);
            }
            x = x + H;
        }
        while (x <= B);
    }
}
