import static java.lang.Math.*;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
        double P = 1;
        for(double a=1; a<=3; a++){
            double S=0;
            for(double b=1; b<=10; b++) {
                S = (S + (log(a + b / 2)));
                System.out.printf("a=%.1f b=%.1f log=%.3f\n", a, b, log(a + b / 2));
            }
            P=P*S;
        }
        System.out.printf("Итоговое произведение P: %.3f\n", P);
    }
}