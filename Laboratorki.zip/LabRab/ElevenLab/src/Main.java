import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.print("Введите число элементов массива s = ");
        int t = in.nextInt();
        System.out.print("Введите число Z = ");
        int Z = in.nextInt();
        int[] s = new int[t];
        int k = 0;
        double c = 0;
        double[] n = new double[t];
        for (int i = 0; i < t; i++) {
            System.out.print("s[" + (i + 1) + "] = ");
            s[i] = in.nextInt();
        }
        System.out.println("Вывод элементов массива a");
        for (int i = 0; i < t; i++) {
            System.out.println("s[" + (i + 1) + "] = " + s[i]);
        }
        int p = 1;
        for (int i = 0; i < t; i++) {
            if (s[i] > Z) {
                p = p * s[i];
                k++;
            }
        }
        for (int i = 0; i < t; i++) {
            n[i] = (double) s[i]/3-6;
            System.out.println("n["+(i+1)+"] = " + n[i]);
        }
        for (int i = 0; i < t; i++) {
            if(i%2==0){
                c=c+n[i];
            }
        }
        System.out.println("Произведение элементов массива s, больших "+Z+" = " + p +"; Их количество = "+k);
        System.out.println("Сумма элементов массива n, расположенных на четных позициях = "+c);
    }
}