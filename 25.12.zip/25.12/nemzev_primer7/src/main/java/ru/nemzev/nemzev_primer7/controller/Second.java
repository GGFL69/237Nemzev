package ru.nemzev.nemzev_primer7.controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;

import static ru.nemzev.nemzev_primer7.util.Manager.showSecondScene;

public class Second {

    @FXML
    private Button goB;

    @FXML
    void goB(ActionEvent event) {
        showSecondScene("hello-view.fxml","Marathon Skills 2016");
    }

}
