package ru.nemzev.nemzev_primer7.controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;

import java.net.URL;
import java.util.ResourceBundle;

import static ru.nemzev.nemzev_primer7.util.Manager.showSecondScene;

public class MainController implements Initializable {

    @FXML
    private Button go;

    @FXML
    void gobtn(ActionEvent event) {
showSecondScene("second.fxml","Marathon Skills 2016");
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
go.setStyle("-fx-background-color: #20B2AA; -fx-background-radius: 5px; -fx-text-fill: #ffffff");
    }
}
