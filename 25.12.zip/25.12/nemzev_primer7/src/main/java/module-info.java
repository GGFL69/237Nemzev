module ru.staroverov.staroverov_primer {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.desktop;


    opens ru.nemzev.nemzev_primer7 to javafx.fxml;
    exports ru.nemzev.nemzev_primer7;
    exports ru.nemzev.nemzev_primer7.controller;
    opens ru.nemzev.nemzev_primer7.controller to javafx.fxml;
}