package ru.nemzev.nemzev_marathon.Controller;

import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;

import static ru.nemzev.nemzev_marathon.util.Manager.showMenuScene;

public class Contacts {

    @FXML
    private Button Close;

    @FXML
    void close(ActionEvent event) {
        showMenuScene("seven.fxml", "Marathon Skills 2016 - Runner menu");
    }

}
