package ru.nemzev.nemzev_marathon.Controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;

import static ru.nemzev.nemzev_marathon.util.Manager.showSecondScene;

public class Third {

    @FXML
    private Button BackB;

    @FXML
    private Button Cancel;

    @FXML
    private TextField emailcheck;

    @FXML
    private TextField passcheck;

    @FXML
    private Button login;

    @FXML
    void BackB(ActionEvent event) {
        showSecondScene("second.fxml", "Marathon Skills 2016 - Register as a runner");
    }

    @FXML
    void Cancel(ActionEvent event) {
        showSecondScene("second.fxml", "Marathon Skills 2016 - Register as a runner");
    }

    @FXML
    void login(ActionEvent event) {
        String emailInput = emailcheck.getText().trim();
        String passwordInput = passcheck.getText().trim();

        String registeredEmail = Fourth.getRegisteredEmail();
        String registeredPassword = Fourth.getRegisteredPassword();

        if (registeredEmail == null || registeredPassword == null) {

            return;
        }

        if (emailInput.equals(registeredEmail) && passwordInput.equals(registeredPassword)) {

            showSecondScene("fifth.fxml", "Marathon Skills 2016 - Register as a runner");

        }
    }
}