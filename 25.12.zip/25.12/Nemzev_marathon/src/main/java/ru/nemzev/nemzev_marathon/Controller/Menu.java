package ru.nemzev.nemzev_marathon.Controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.layout.AnchorPane;

import java.awt.event.MouseEvent;
import java.net.URL;
import java.util.ResourceBundle;

import static ru.nemzev.nemzev_marathon.util.Manager.showContactScene;
import static ru.nemzev.nemzev_marathon.util.Manager.showSecondScene;

public class Menu implements Initializable {

    @FXML
    private Button BackB;

    @FXML
    private Button Close;

    @FXML
    private Button Contact;

    @FXML
    private Button Reg;

    @FXML
    private AnchorPane anchor;

    DraggableMaker draggableMaker = new DraggableMaker();

    @FXML
    void BackB(ActionEvent event) {
        showSecondScene("third.fxml", "Marathon Skills 2016");
    }

    @FXML
    void Contact(ActionEvent event) {
        anchor.setVisible(true);
    }

    @FXML
    void Reg(ActionEvent event) {
        showSecondScene("fourth.fxml", "Marathon Skills 2016 - Register as a runner");
    }


    @FXML
    void close(ActionEvent event) {
        anchor.setVisible(false);
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        draggableMaker.makeDraggable(anchor);
    }
}

