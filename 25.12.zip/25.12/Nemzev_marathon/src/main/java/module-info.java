module ru.nemzev.nemzev_marathon {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.desktop;


    opens ru.nemzev.nemzev_marathon to javafx.fxml;
    exports ru.nemzev.nemzev_marathon;
    exports ru.nemzev.nemzev_marathon.Controller;
    opens ru.nemzev.nemzev_marathon.Controller to javafx.fxml;
}